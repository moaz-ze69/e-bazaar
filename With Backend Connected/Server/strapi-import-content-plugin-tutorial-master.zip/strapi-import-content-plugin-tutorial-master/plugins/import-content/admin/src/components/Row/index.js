import styled from 'styled-components';

const Row = styled.div`
  padding-top: 18px;
`;

export default Row;
