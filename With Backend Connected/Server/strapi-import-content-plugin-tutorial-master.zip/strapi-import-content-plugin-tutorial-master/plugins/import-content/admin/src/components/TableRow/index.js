import styled from 'styled-components';

const Row = styled.tr`
  padding-top: 18px;
`;

export default Row;
