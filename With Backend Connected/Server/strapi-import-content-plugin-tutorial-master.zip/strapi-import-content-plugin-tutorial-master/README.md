# Strapi Import Content Plugin Tutorial

All the credits belong to https://github.com/jbeuckm who developed this wonderful plugin: https://github.com/jbeuckm/strapi-plugin-import-content

----

The current plugin only introduced some new UI changes on the original plugin. 

Based on strapi-beta: 17.5

----  

# Setup

yarn install

------

yarn run develop --watch-admin 

or
 
 npx strapi develop --watch-admin

-----

Allow Public Access on all the endpoints of this plugin.

Allow Public Access on getmodels endpoint of the Content Type Builder plugin.
